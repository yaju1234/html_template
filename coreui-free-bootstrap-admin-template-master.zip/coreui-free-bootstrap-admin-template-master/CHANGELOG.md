## v2.1.0

- **Feat: Add pug support**
- Update: @coreui/coreui-icons to 0.3.0
- Update: @coreui/coreui to 2.0.3
- Update: perfect-scrollbar to 1.4.0
